const CACHE_NAME = "isc-pool-tracker-v2";

const APP_SHELL = [
    "/",
    "/static/tracker/manifest.json"
];

self.addEventListener("install", event => {
    event.waitUntil(
        caches.open(CACHE_NAME).then(cache => {
            return cache.addAll(APP_SHELL);
        })
    );

    self.skipWaiting();
});


self.addEventListener("activate", event => {
    event.waitUntil(
        caches.keys().then(cacheNames => {
            return Promise.all(
                cacheNames
                    .filter(name => name !== CACHE_NAME)
                    .map(name => caches.delete(name))
            );
        })
    );

    self.clients.claim();
});


self.addEventListener("fetch", event => {

    if (event.request.method !== "GET") {
        return;
    }

    event.respondWith(
        fetch(event.request)
            .then(response => {

                const responseClone =
                    response.clone();

                caches.open(CACHE_NAME).then(cache => {
                    cache.put(
                        event.request,
                        responseClone
                    );
                });

                return response;
            })
            .catch(() => {
                return caches.match(event.request);
            })
    );
});
